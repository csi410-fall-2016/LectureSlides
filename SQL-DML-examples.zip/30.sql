/* Query 30 */
/* Count the number of departments that offer courses. */


SELECT COUNT(DISTINCT cdept) 
FROM Course;
