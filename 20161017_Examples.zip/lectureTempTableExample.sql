DROP TABLE IF EXISTS DeptBgtTemp;

CREATE TEMPORARY TABLE IF NOT EXISTS DeptBgtTemp 
  LIKE Department;

ALTER TABLE DeptBgtTemp
  DROP COLUMN dname,
  ADD COLUMN (over_bgt TINYINT(1) NOT NULL, fid INT, fsalary NUMERIC(10,2), fsalary_sum NUMERIC(10,2)),
  DROP PRIMARY KEY,
  ADD PRIMARY KEY (ddept, fid),
  ADD INDEX over_bgt_idx (over_bgt);


INSERT INTO DeptBgtTemp (ddept, dsalary_budget, fsalary_sum, over_bgt, fid, fsalary)
  SELECT ddept, 
       dsalary_budget,
       fsalary_sum,
       (fsalary_sum > dsalary_budget) AS over_bgt,
       fid,
       fsalary
  FROM (
    (SELECT dept, SUM(sal) AS fsalary_sum
     FROM (
       SELECT Department.ddept AS dept, 0 AS sal 
         FROM Department
       UNION ALL
       SELECT fdept AS dept, SUM(fsalary) sal 
         FROM Faculty
         GROUP BY fdept) AS t1
       GROUP BY dept) AS SalSums
   INNER JOIN Department 
     ON (SalSums.dept = ddept) 
   INNER JOIN Faculty 
     ON (ddept = fdept)
 );
