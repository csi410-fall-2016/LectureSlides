/* Query 6 */

SELECT * 
FROM Department, Faculty
WHERE ddept = fdept;
