DROP TABLE IF EXISTS FacultyDeptsCopy;
CREATE TABLE FacultyDeptsCopy
  (fdept CHAR(3) UNIQUE)
  AS SELECT fdept FROM uncle_ted_sample.Faculty;
/* ERROR 1062 (23000): Duplicate entry 'CSI' for key 'fdept' */


DROP TABLE IF EXISTS FacultyDeptsCopy;
CREATE TABLE FacultyDeptsCopy
  (fid INT, fdept CHAR(3) UNIQUE)
  IGNORE
  AS SELECT fid, fdept FROM uncle_ted_sample.Faculty;
/*
mysql> select * from FacultyDeptsCopy;
+-------+-------+
| fid   | fdept |
+-------+-------+
| 52110 | ADM   |
| 21004 | BIO   |
| 12058 | CSI   |
| 12206 | ENG   |
+-------+-------+
4 rows in set (0.00 sec)
*/

DROP TABLE IF EXISTS FacultyDeptsCopy;
CREATE TABLE FacultyDeptsCopy
  (fid INT, fdept CHAR(3) UNIQUE)
  REPLACE
  AS SELECT fid, fdept FROM uncle_ted_sample.Faculty;
/*
mysql> select * from FacultyDeptsCopy;
+-------+-------+
| fid   | fdept |
+-------+-------+
| 52110 | ADM   |
| 31890 | BIO   |
| 32000 | CSI   |
| 47862 | ENG   |
+-------+-------+
4 rows in set (0.00 sec)
*/
