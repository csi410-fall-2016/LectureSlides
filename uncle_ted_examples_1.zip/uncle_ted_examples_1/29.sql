/* Query 29 */
/* Count the number of non-null fid values in Faculty. */

SELECT COUNT(fid) 
FROM Faculty;
