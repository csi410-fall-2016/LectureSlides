/* Query 5 */

SELECT fid, ffirst, fmi, flast, fsalary
FROM Faculty
ORDER BY flast, ffirst, fmi;
