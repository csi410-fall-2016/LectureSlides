/* Query 1 */

SELECT *
FROM Department;
