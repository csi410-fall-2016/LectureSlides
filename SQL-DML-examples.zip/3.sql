/* Query 3 */
SELECT DISTINCT ffirst
FROM Faculty;
