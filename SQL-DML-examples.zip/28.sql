/* Query 28 */
/* Count the number of rows in Faculty. */

SELECT COUNT(*) 
FROM Faculty;
