/* Query 8 */

SELECT *
FROM Department, Course
WHERE ddept = cdept;
