/* Query 2 */

SELECT flast, ffirst, fdept, fsalary
FROM Faculty;
