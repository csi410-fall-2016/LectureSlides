/* Query 4 */

SELECT *
FROM Course
ORDER BY cname DESC;
