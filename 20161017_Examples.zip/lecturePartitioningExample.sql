DROP TABLE IF EXISTS boxers;

CREATE TABLE boxers (
  rank INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100))
ENGINE=InnoDB
PARTITION BY RANGE (rank) PARTITIONS 3 (
PARTITION P1 VALUES LESS THAN (2)
  DATA DIRECTORY = '/demo_data/boxers_1/',
PARTITION P2 VALUES LESS THAN (4)
  DATA DIRECTORY = '/demo_data/boxers_2/',
PARTITION P3 VALUES LESS THAN MAXVALUE
  DATA DIRECTORY = '/demo_data/boxers_3/');


INSERT INTO boxers (name) 
VALUES ('Ray Robinson'),
       ('Muhammad Ali'),
       ('Henry Armstrong'),
       ('Joe Louis'),
       ('Willie Pep'),
       ('Roberto Duran'),
       ('Benny Leonard'),
       ('Jack Johnson'),
       ('Jack Dempsey'),
       ('Sam Langford');
